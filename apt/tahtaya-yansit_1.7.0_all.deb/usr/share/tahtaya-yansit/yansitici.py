#!/usr/bin/env python3
"""Tahtaya Yansıt — tahtada çalışan alıcı.

Oturum açılınca arka planda başlar. Yeni bir telefon bağlanmak istediğinde
tahtada "Kodu göster / Reddet" sorulur; kod ancak tahtada dokunulunca görünür.
Yayın gelince görüntü tam ekranda, ses hoparlörde oynatılır; görüntünün
üzerine kalemle çizilebilir.
"""

import os
import json
import sys
import threading
import time
import urllib.parse

import cairo
import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gst", "1.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gst, Gtk  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cekirdek  # noqa: E402

try:
    import qrcode  # python3-qrcode; yoksa QR gösterilmez, kod yine çalışır
except ImportError:
    qrcode = None

UYGULAMA_KIMLIGI = "tr.eray.TahtayaYansit"
SIMGE = "tahtaya-yansit"

_KLASOR = os.path.dirname(os.path.abspath(__file__))
# Pakette logo betiğin yanında; geliştirirken proje klasöründeki kesilmiş logo kullanılır.
LOGO = next((y for y in (os.path.join(_KLASOR, "logo.png"),
                         os.path.join(_KLASOR, "..", "..", "logo-src", "kesik2", "logo-512.png"))
             if os.path.exists(y)), os.path.join(_KLASOR, "logo.png"))

CSS = b"""
.bilgi-penceresi {
    background-image: linear-gradient(to bottom, #f8fbfe, #e4edf6);
}
.kart {
    background-image: linear-gradient(to bottom, rgba(255,255,255,0.97), rgba(255,255,255,0.85));
    border: 1px solid #ffffff;
    border-radius: 24px;
    box-shadow: 0 6px 20px rgba(31,58,104,0.12);
    padding: 22px 28px;
}
.uygulama-adi { font-size: 30px; font-weight: 600; color: #14223a; }
.alt-baslik { font-size: 15px; color: #6b7a90; }
.baslik { font-size: 14px; font-weight: 600; color: #6b7a90; letter-spacing: 2px; }
.pin { font-size: 110px; font-weight: 700; letter-spacing: 22px; color: #1f3a68; }
.pin-gizli { font-size: 110px; font-weight: 700; letter-spacing: 22px; color: #c5cfdb; }
.istek, .uyari {
    color: #ffffff; border-radius: 18px; padding: 14px 20px;
}
.istek-yazi { font-size: 20px; font-weight: 600; color: #ffffff; }
.istek { background-image: linear-gradient(to right, #1f3a68, #4a90b0); }
.uyari { background-image: linear-gradient(to right, #b3261e, #e5484d); }
.bilgi { font-size: 16px; color: #3d4b60; }
.soluk { font-size: 14px; color: #6b7a90; }
.cam-dugme {
    background-image: linear-gradient(to bottom, #ffffff, #eef3f8);
    border: 1px solid rgba(31,58,104,0.15);
    border-radius: 22px; padding: 8px 20px; color: #1f3a68; box-shadow: none;
}
.ana-dugme {
    background-image: linear-gradient(to bottom, rgba(255,255,255,0.3), rgba(255,255,255,0) 50%),
                      linear-gradient(to right, #1f3a68, #4a90b0);
    border: none; border-radius: 22px; padding: 8px 24px; color: #ffffff; box-shadow: none;
}
.buyuk { font-size: 20px; padding: 12px 28px; border-radius: 26px; }
entry.giris { border-radius: 14px; padding: 8px 12px; min-height: 30px; }
.yayin { background-color: black; }
.bitir { font-size: 22px; padding: 14px 24px; border-radius: 26px; }
.arac-cubugu {
    background-color: rgba(20,34,58,0.82); border-radius: 30px; padding: 8px 12px;
}
.arac { font-size: 22px; padding: 10px 16px; border-radius: 22px; color: #ffffff;
        background-image: none; background-color: transparent; border: none; box-shadow: none; }
.arac:checked { background-color: rgba(255,255,255,0.25); }
.arac image { color: #ffffff; }
.renk { min-width: 34px; min-height: 34px; border-radius: 17px; border: 3px solid rgba(255,255,255,0.6);
        padding: 0; background-image: none; box-shadow: none; }
.renk:checked { border-color: #ffffff; }
.cihaz-etiketi { background-color: rgba(20,34,58,0.82); color: #ffffff; font-size: 18px;
                 border-radius: 22px; padding: 10px 18px; }
.arac-yazili { font-size: 17px; }
.arac-yazili label { color: #ffffff; }
.gosterge-iyi { color: #7cf29a; }
.gosterge-orta { color: #ffd166; }
.gosterge-zayif { color: #ff8a8a; }
.kontrol-rozeti { background-image: none; border: none; box-shadow: none; }
.duraklat-rozeti { background-color: rgba(20,34,58,0.82); color: #ffffff; font-size: 22px;
                   font-weight: 600; border-radius: 26px; padding: 12px 26px; }
"""

KALEM_RENKLERI = ["#e5484d", "#f5c518", "#2e9bff", "#30c46a", "#ffffff"]


def video_cikisi_yap():
    """(gst öğesi, gtk bileşeni). Önce GL ile çizim, olmazsa yazılımla."""
    if os.environ.get("YANSITICI_GL", "1") != "0":
        glsink = Gst.ElementFactory.make("gtkglsink", None)
        kutu = Gst.ElementFactory.make("glsinkbin", None)
        if glsink and kutu:
            kutu.set_property("sink", glsink)
            return kutu, glsink.props.widget
    sink = Gst.ElementFactory.make("gtksink", None)
    return sink, sink.props.widget


def video_cozucu():
    """Ekran kartı H.264 çözebiliyorsa onu kullan (güçsüz tahtalarda işlemciyi rahatlatır)."""
    if os.environ.get("YANSITICI_DONANIM", "1") != "0":
        for ad in ("vah264dec", "vaapih264dec"):
            if Gst.ElementFactory.find(ad):
                return ad
    return "avdec_h264"


class Oynatici:
    """Gelen H.264 görüntüyü ve AAC sesi çözüp oynatan GStreamer hattı.
    Görüntü yolunda döndürme (videoflip) ve dondurma (valve), ses yolunda ses seviyesi var."""

    YONLER = ["identity", "90r", "180", "90l"]

    def __init__(self, ses, hata):
        self.hata = hata
        self.video_ayar = b""
        self.cozucu = video_cozucu()
        self.yon = 0
        tanim = (
            "appsrc name=vsrc is-live=true format=time do-timestamp=true "
            "max-bytes=8000000 caps=video/x-h264,stream-format=byte-stream,alignment=au "
            f"! h264parse ! {self.cozucu} ! videoconvert ! videoflip name=yon "
            "! valve name=dondur drop=false ! queue name=vq max-size-buffers=3"
        )
        if ses:
            if Gst.ElementFactory.find("pulsesink"):
                # Varsayılan 200 ms tampon sesi görüntünün gerisinde bırakır.
                ses_cikisi = "pulsesink buffer-time=100000 latency-time=10000"
            else:
                ses_cikisi = "autoaudiosink"
            tanim += (
                " appsrc name=asrc is-live=true format=time do-timestamp=true "
                "caps=audio/mpeg,mpegversion=4,stream-format=adts "
                "! aacparse ! decodebin ! audioconvert ! audioresample ! volume name=seviye "
                f"! queue max-size-time=300000000 leaky=downstream ! {ses_cikisi} name=ses"
            )
        self.hat = Gst.parse_launch(tanim)
        self.vsrc = self.hat.get_by_name("vsrc")
        self.asrc = self.hat.get_by_name("asrc")
        self.seviye = self.hat.get_by_name("seviye")
        self.yon_ogesi = self.hat.get_by_name("yon")
        self.vana = self.hat.get_by_name("dondur")
        ses_ogesi = self.hat.get_by_name("ses")
        if ses_ogesi and ses_ogesi.find_property("sync"):
            ses_ogesi.set_property("sync", False)
        self.sink, self.bilesen = video_cikisi_yap()
        self.sink.set_property("sync", False)
        self.hat.add(self.sink)
        self.hat.get_by_name("vq").link(self.sink)
        veri_yolu = self.hat.get_bus()
        veri_yolu.add_signal_watch()
        veri_yolu.connect("message::error", self._hata)

    def _hata(self, _yol, mesaj):
        hata, ayrinti = mesaj.parse_error()
        cekirdek.kayit.error("GStreamer hatası: %s (%s)", hata.message, ayrinti)
        self.hata(hata.message)

    def baslat(self):
        return self.hat.set_state(Gst.State.PLAYING) != Gst.StateChangeReturn.FAILURE

    def durdur(self):
        self.hat.set_state(Gst.State.NULL)
        self.hat.get_bus().remove_signal_watch()

    def dondur(self, evet):
        """Dondurulunca kareler ekrana gitmez; son kare kalır. Çözme sürer, devamda bekleme olmaz."""
        self.vana.set_property("drop", evet)

    def dondurulmus(self):
        return self.vana.get_property("drop")

    def dondur_yonu(self):
        self.yon = (self.yon + 1) % 4
        Gst.util_set_object_arg(self.yon_ogesi, "video-direction", self.YONLER[self.yon])

    def ses_seviyesi(self, deger):
        if self.seviye:
            self.seviye.set_property("volume", deger)

    def kare(self, tur, bayrak, veri):
        if tur == cekirdek.T_VIDEO_AYAR:
            self.video_ayar = veri
        elif tur == cekirdek.T_VIDEO:
            if bayrak & cekirdek.B_ANAHTAR and self.video_ayar:
                veri = self.video_ayar + veri
            self.vsrc.emit("push-buffer", Gst.Buffer.new_wrapped(veri))
        elif tur == cekirdek.T_SES and self.asrc:
            self.asrc.emit("push-buffer", Gst.Buffer.new_wrapped(veri))


def one_getir(pencere):
    """Pencereyi kesin öne getir. Arka planda çalışan uygulamanın açtığı pencereyi GNOME gibi
    masaüstleri "odak çalma" sayıp arkada bırakabilir; X sunucu zamanıyla istemek bunu aşar."""
    zaman = Gdk.CURRENT_TIME
    try:
        gi.require_version("GdkX11", "3.0")
        from gi.repository import GdkX11
        gw = pencere.get_window()
        if gw is not None and isinstance(gw, GdkX11.X11Window):
            zaman = GdkX11.x11_get_server_time(gw)
    except (ImportError, ValueError, AttributeError):
        pass
    pencere.present_with_time(zaman)


def sinifli(widget, *siniflar):
    for s in siniflar:
        widget.get_style_context().add_class(s)
    return widget


def simgeli(dugme, simge):
    dugme.set_image(Gtk.Image.new_from_icon_name(simge, Gtk.IconSize.LARGE_TOOLBAR))
    dugme.set_always_show_image(True)
    return dugme


KALINLIKLAR = [4, 7, 12]


class CizimKatmani(Gtk.DrawingArea):
    """Yansıtılan görüntünün üzerine kalemle çizim. Noktalar 0-1 arası tutulur,
    pencere boyutu değişse de çizim yerinde kalır."""

    def __init__(self):
        super().__init__()
        self.cizgiler = []  # [(renk, kalinlik, saydamlik, [(x, y), ...])]
        self.renk = KALEM_RENKLERI[0]
        self.kalinlik = KALINLIKLAR[1]
        self.fosforlu = False
        self.silgi = False
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK
                        | Gdk.EventMask.BUTTON1_MOTION_MASK)
        self.connect("draw", self._ciz)
        self.connect("button-press-event", self._bas)
        self.connect("motion-notify-event", self._surukle)

    def _oran(self, olay):
        a = self.get_allocation()
        return olay.x / max(1, a.width), olay.y / max(1, a.height)

    def _bas(self, _w, olay):
        if self.silgi:
            self._sil(self._oran(olay))
        elif self.fosforlu:
            self.cizgiler.append((self.renk, self.kalinlik * 3, 0.35, [self._oran(olay)]))
        else:
            self.cizgiler.append((self.renk, self.kalinlik, 0.95, [self._oran(olay)]))
        self.queue_draw()
        return True

    def _surukle(self, _w, olay):
        if self.silgi:
            self._sil(self._oran(olay))
        elif self.cizgiler:
            self.cizgiler[-1][3].append(self._oran(olay))
        self.queue_draw()
        return True

    def _sil(self, nokta):
        x, y = nokta
        self.cizgiler = [c for c in self.cizgiler
                         if all(abs(px - x) > 0.025 or abs(py - y) > 0.035 for px, py in c[3])]

    def geri_al(self):
        if self.cizgiler:
            self.cizgiler.pop()
            self.queue_draw()

    def temizle(self):
        self.cizgiler = []
        self.queue_draw()

    def _ciz(self, _w, cr):
        a = self.get_allocation()
        cr.set_line_cap(cairo.LINE_CAP_ROUND)
        cr.set_line_join(cairo.LINE_JOIN_ROUND)
        for renk, kalinlik, saydamlik, noktalar in self.cizgiler:
            rgba = Gdk.RGBA()
            rgba.parse(renk)
            cr.set_source_rgba(rgba.red, rgba.green, rgba.blue, saydamlik)
            cr.set_line_width(kalinlik * a.height / 720)
            x0, y0 = noktalar[0]
            cr.move_to(x0 * a.width, y0 * a.height)
            if len(noktalar) == 1:
                cr.line_to(x0 * a.width + 0.1, y0 * a.height)
            for x, y in noktalar[1:]:
                cr.line_to(x * a.width, y * a.height)
            cr.stroke()
        return False


def cizimli_simge(ciz, boyut=26):
    """Simge temasında olmayan simgeleri (kalınlık, fosforlu) cairo ile çizer."""
    alan = Gtk.DrawingArea()
    alan.set_size_request(boyut, boyut)
    alan.connect("draw", lambda w, cr: (ciz(cr, w.get_allocated_width(), w.get_allocated_height()), False)[1])
    return alan


class YayinPenceresi(Gtk.Window):
    YAKINLIK = [1.0, 1.5, 2.0, 3.0]

    def __init__(self, oynatici, cihaz_adi, bitir, dokun=None):
        super().__init__(title="Tahtaya Yansıt")
        self.oynatici = oynatici
        self.bitir = bitir
        self.dokun = dokun            # dokun(eylem, u, v): dokunuşu telefona yollar
        self.kontrol_acik = False
        self.basili = False
        self.son_nokta = None
        self.son_gonderim = 0.0
        self.yakinlik = 0
        self.telefon_duraklatti = False
        self.get_style_context().add_class("yayin")
        self.set_icon_name(SIMGE)
        self.katman = Gtk.Overlay()

        # Görüntü: yakınlaştırınca kaydırılabilsin diye kaydırma alanında
        self.kaydirma = Gtk.ScrolledWindow()
        self.kaydirma.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.kaydirma.set_kinetic_scrolling(True)
        olay = Gtk.EventBox()
        olay.add(oynatici.bilesen)
        olay.add_events(Gdk.EventMask.POINTER_MOTION_MASK | Gdk.EventMask.TOUCH_MASK
                        | Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK)
        olay.connect("motion-notify-event", self._video_olayi, cekirdek.D_SURUKLE)
        olay.connect("button-press-event", self._video_olayi, cekirdek.D_BAS)
        olay.connect("button-release-event", self._video_olayi, cekirdek.D_BIRAK)
        olay.connect("touch-event", self._parmak_olayi)
        self.parmak = None  # kontrolde izlenen dokunuş (ikinci parmak yok sayılır)
        self.video = olay
        self.kaydirma.add(olay)
        self.katman.add(self.kaydirma)
        # Fareyle sürükleyerek kaydırma ve iki parmakla yakınlaştırma
        self.surukle = Gtk.GestureDrag.new(self.kaydirma)
        self.surukle.connect("drag-begin", self._surukle_basla)
        self.surukle.connect("drag-update", self._surukle_devam)
        self.yakinlastir_hareketi = Gtk.GestureZoom.new(self.kaydirma)
        self.yakinlastir_hareketi.connect("scale-changed", self._iki_parmak)

        # Çizim katmanı: kalem kapalıyken dokunuşlar alttaki görüntüye geçer.
        self.cizim = CizimKatmani()
        self.katman.add_overlay(self.cizim)
        self.katman.set_overlay_pass_through(self.cizim, True)

        # Durum rozeti (duraklatıldı / donduruldu) ve kısa bildirim
        self.rozet = sinifli(Gtk.Label(), "duraklat-rozeti")
        self.rozet.set_halign(Gtk.Align.CENTER)
        self.rozet.set_valign(Gtk.Align.START)
        self.rozet.set_margin_top(24)
        self.rozet.set_no_show_all(True)
        self.katman.add_overlay(self.rozet)
        self.katman.set_overlay_pass_through(self.rozet, True)
        self.bildirim = sinifli(Gtk.Label(), "duraklat-rozeti")
        self.bildirim.set_halign(Gtk.Align.CENTER)
        self.bildirim.set_valign(Gtk.Align.CENTER)
        self.bildirim.set_no_show_all(True)
        self.katman.add_overlay(self.bildirim)
        self.katman.set_overlay_pass_through(self.bildirim, True)

        # Üstte: bağlantı göstergesi + cihaz adı + bitir
        self.ust = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN)
        self.ust.set_halign(Gtk.Align.END)
        self.ust.set_valign(Gtk.Align.START)
        kutu = Gtk.Box(spacing=12, margin=16)
        self.gosterge = sinifli(Gtk.Label(label="● Bağlantı iyi"), "cihaz-etiketi", "gosterge-iyi")
        kutu.pack_start(self.gosterge, False, False, 0)
        kutu.pack_start(sinifli(Gtk.Label(label=cihaz_adi), "cihaz-etiketi"), False, False, 0)
        dugme = sinifli(Gtk.Button(label="✕  Yansıtmayı bitir"), "bitir", "destructive-action")
        dugme.connect("clicked", lambda *_: self.bitir())
        kutu.pack_start(dugme, False, False, 0)
        self.ust.add(kutu)
        self.katman.add_overlay(self.ust)

        # Solda: kalem araçları
        self.arac = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_RIGHT)
        self.arac.set_halign(Gtk.Align.START)
        self.arac.set_valign(Gtk.Align.CENTER)
        cubuk = sinifli(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin=16),
                        "arac-cubugu")
        self.kalem = sinifli(simgeli(Gtk.ToggleButton(), "document-edit-symbolic"), "arac")
        self.kalem.set_tooltip_text("Kalem")
        self.kalem.connect("toggled", self._kalem_degisti)
        cubuk.pack_start(self.kalem, False, False, 0)
        self.renk_dugmeleri = []
        ilk = None
        for renk in KALEM_RENKLERI:
            r = Gtk.RadioButton.new_from_widget(ilk)
            ilk = ilk or r
            r.set_mode(False)
            sinifli(r, "renk")
            saglayici = Gtk.CssProvider()
            saglayici.load_from_data(f"button {{ background-color: {renk}; }}".encode())
            r.get_style_context().add_provider(saglayici, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)
            r.connect("toggled", self._renk_secildi, renk)
            r.set_halign(Gtk.Align.CENTER)
            cubuk.pack_start(r, False, False, 0)
            self.renk_dugmeleri.append(r)
        # Kalınlık: dokundukça ince → orta → kalın
        self.kalinlik_dugmesi = sinifli(Gtk.Button(), "arac")
        self.kalinlik_dugmesi.set_tooltip_text("Kalınlık")
        self.kalinlik_dugmesi.add(cizimli_simge(self._kalinlik_simgesi))
        self.kalinlik_dugmesi.connect("clicked", self._kalinlik_degistir)
        cubuk.pack_start(self.kalinlik_dugmesi, False, False, 0)
        # Fosforlu kalem: yarı saydam, kalın
        self.fosforlu = sinifli(Gtk.ToggleButton(), "arac")
        self.fosforlu.set_tooltip_text("Fosforlu kalem")
        self.fosforlu.add(cizimli_simge(self._fosforlu_simgesi))
        self.fosforlu.connect("toggled", self._fosforlu_degisti)
        cubuk.pack_start(self.fosforlu, False, False, 0)
        self.silgi = sinifli(simgeli(Gtk.ToggleButton(), "edit-clear-symbolic"), "arac")
        self.silgi.set_tooltip_text("Silgi")
        self.silgi.connect("toggled", self._silgi_degisti)
        cubuk.pack_start(self.silgi, False, False, 0)
        geri = sinifli(simgeli(Gtk.Button(), "edit-undo-symbolic"), "arac")
        geri.set_tooltip_text("Geri al")
        geri.connect("clicked", lambda *_: self.cizim.geri_al())
        cubuk.pack_start(geri, False, False, 0)
        temizle = sinifli(simgeli(Gtk.Button(), "user-trash-symbolic"), "arac")
        temizle.set_tooltip_text("Hepsini sil")
        temizle.connect("clicked", lambda *_: self.cizim.temizle())
        cubuk.pack_start(temizle, False, False, 0)
        self.arac.add(cubuk)
        self.katman.add_overlay(self.arac)

        # Altta: görüntü araçları
        self.alt = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_UP)
        self.alt.set_halign(Gtk.Align.CENTER)
        self.alt.set_valign(Gtk.Align.END)
        alt_kutu = sinifli(Gtk.Box(spacing=6, margin=16), "arac-cubugu")
        self.dondur_dugmesi = self._alt_dugme(alt_kutu, Gtk.ToggleButton(), "media-playback-pause-symbolic",
                                              "Dondur")
        self.dondur_dugmesi.connect("toggled", self._dondur_degisti)
        self._alt_dugme(alt_kutu, Gtk.Button(), "zoom-in-symbolic", "Büyüt").connect(
            "clicked", lambda *_: self._yakinlastir(1))
        self._alt_dugme(alt_kutu, Gtk.Button(), "zoom-out-symbolic", "Küçült").connect(
            "clicked", lambda *_: self._yakinlastir(-1))
        self._alt_dugme(alt_kutu, Gtk.Button(), "object-rotate-right-symbolic", "Döndür").connect(
            "clicked", lambda *_: self.oynatici.dondur_yonu())
        self._alt_dugme(alt_kutu, Gtk.Button(), "document-save-symbolic", "Kaydet").connect(
            "clicked", lambda *_: self.kaydet())
        # Telefon izin verdiyse görünür: tahtadaki dokunuşlar telefonda uygulanır
        self.kontrol_dugmesi = self._alt_dugme(alt_kutu, Gtk.ToggleButton(), "input-mouse-symbolic",
                                               "Dokunarak kontrol")
        self.kontrol_dugmesi.set_no_show_all(True)
        self.kontrol_dugmesi.connect("toggled", self._kontrol_degisti)
        if oynatici.seviye:
            ses = sinifli(Gtk.VolumeButton(), "arac")
            ses.set_value(1.0)
            ses.connect("value-changed", lambda _b, d: self.oynatici.ses_seviyesi(d))
            alt_kutu.pack_start(ses, False, False, 0)
        self.alt.add(alt_kutu)
        self.katman.add_overlay(self.alt)

        # Kontrol açıkken araç çubukları dokunuşla açılmaz; bu düğmeyle kapatılır
        self.kontrol_rozeti = sinifli(Gtk.Button(label="Dokunarak kontrol açık  ·  Kapat"),
                                      "duraklat-rozeti", "kontrol-rozeti")
        self.kontrol_rozeti.set_halign(Gtk.Align.END)
        self.kontrol_rozeti.set_valign(Gtk.Align.END)
        self.kontrol_rozeti.set_margin_end(20)
        self.kontrol_rozeti.set_margin_bottom(20)
        self.kontrol_rozeti.set_no_show_all(True)
        self.kontrol_rozeti.connect("clicked", lambda *_: self.kontrol_dugmesi.set_active(False))
        self.katman.add_overlay(self.kontrol_rozeti)
        self.add(self.katman)

        self.connect("key-press-event", self._tus)
        self.connect("delete-event", lambda *_: (self.bitir(), True)[1])
        self.gizle_zamanlayici = 0
        self.bildirim_zamanlayici = 0
        self.show_all()
        self.fullscreen()
        self.set_keep_above(True)
        one_getir(self)
        self._dokunuldu()

    @staticmethod
    def _alt_dugme(kutu, dugme, simge, yazi):
        icerik = Gtk.Box(spacing=8)
        icerik.pack_start(Gtk.Image.new_from_icon_name(simge, Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        icerik.pack_start(Gtk.Label(label=yazi), False, False, 0)
        dugme.add(icerik)
        sinifli(dugme, "arac", "arac-yazili")
        kutu.pack_start(dugme, False, False, 0)
        return dugme

    # --- tahtadan dokunarak kontrol ---

    def kontrol_durumu(self, durum):
        """Telefonun bildirdiği izin: izin varsa düğme görünür, yoksa kip kapanır."""
        izin = bool(durum.get("izin"))
        self.kontrol_dugmesi.set_visible(izin)
        if not izin and self.kontrol_dugmesi.get_active():
            self.kontrol_dugmesi.set_active(False)
            self.bildir("Telefonda tahtadan kontrol kapatıldı")
        if durum.get("uyari"):
            self.bildir(durum["uyari"], 4)
        return False

    def _kontrol_degisti(self, dugme):
        self.kontrol_acik = dugme.get_active()
        self.basili = False
        self.parmak = None
        if self.kontrol_acik:
            self.kalem.set_active(False)
            self.kontrol_rozeti.show()
            self._gizle()
            self.arac.set_reveal_child(False)
            self.bildir("Dokunuşlar telefona gidiyor. Kapatmak için sağ alttaki düğme.", 3)
        else:
            self.kontrol_rozeti.hide()

    def _kare_boyutu(self):
        try:
            yapi = self.oynatici.sink.get_static_pad("sink").get_current_caps().get_structure(0)
            return yapi.get_int("width")[1], yapi.get_int("height")[1]
        except (AttributeError, TypeError, IndexError):
            return 0, 0

    def _parmak_olayi(self, w, olay):
        """Dokunmatik tahta: dokunma olayları fareye çevrilmeden doğrudan gelir."""
        eylem = {Gdk.EventType.TOUCH_BEGIN: cekirdek.D_BAS, Gdk.EventType.TOUCH_UPDATE: cekirdek.D_SURUKLE,
                 Gdk.EventType.TOUCH_END: cekirdek.D_BIRAK,
                 Gdk.EventType.TOUCH_CANCEL: cekirdek.D_BIRAK}.get(olay.type)
        if eylem is None:
            return False
        if not self.kontrol_acik:
            if eylem == cekirdek.D_BAS:
                self._dokunuldu()
            return False
        dizi = olay.get_event_sequence()
        if eylem == cekirdek.D_BAS:
            if self.parmak is not None:
                return True
            self.parmak = dizi
        elif dizi != self.parmak:
            return True
        if eylem == cekirdek.D_BIRAK:
            self.parmak = None
        return self._video_olayi(w, olay, eylem)

    def _video_olayi(self, _w, olay, eylem):
        if not self.kontrol_acik:
            if eylem != cekirdek.D_BIRAK:
                self._dokunuldu()
            return False
        if eylem == cekirdek.D_SURUKLE and not self.basili:
            return True
        a = self.video.get_allocation()
        kg, ky = self._kare_boyutu()
        nokta = cekirdek.dokunma_cevir(olay.x, olay.y, a.width, a.height, kg, ky, self.oynatici.yon)
        simdi = time.monotonic()
        if eylem == cekirdek.D_BAS:
            if nokta is None:
                return True  # görüntünün dışına (siyah boşluğa) dokunuldu
            self.basili = True
        elif eylem == cekirdek.D_SURUKLE:
            if nokta is None or simdi - self.son_gonderim < 0.016:
                return True  # en çok ~60 hareket/sn
        else:
            if not self.basili:
                return True  # basış görüntünün dışındaydı; telefona hiçbir şey gitmez
            self.basili = False
            nokta = nokta or self.son_nokta
        self.son_nokta = nokta
        self.son_gonderim = simdi
        if self.dokun:
            self.dokun(eylem, *nokta)
        return True

    # --- kalem ---

    def _kalinlik_simgesi(self, cr, g, y):
        cr.set_source_rgb(1, 1, 1)
        cr.arc(g / 2, y / 2, {4: 3, 7: 5.5, 12: 9}[self.cizim.kalinlik], 0, 6.2832)
        cr.fill()

    def _fosforlu_simgesi(self, cr, g, y):
        cr.set_source_rgba(0.96, 0.77, 0.09, 0.6)
        cr.rectangle(2, y / 2 - 6, g - 4, 12)
        cr.fill()

    def _kalinlik_degistir(self, dugme):
        i = KALINLIKLAR.index(self.cizim.kalinlik)
        self.cizim.kalinlik = KALINLIKLAR[(i + 1) % len(KALINLIKLAR)]
        dugme.queue_draw()
        self._kalemi_ac()

    def _fosforlu_degisti(self, dugme):
        self.cizim.fosforlu = dugme.get_active()
        if dugme.get_active():
            self.silgi.set_active(False)
            self._kalemi_ac()

    def _kalemi_ac(self):
        if not self.kalem.get_active():
            self.kalem.set_active(True)

    def _kalem_degisti(self, dugme):
        acik = dugme.get_active()
        if acik and self.kontrol_dugmesi.get_active():
            self.kontrol_dugmesi.set_active(False)
        self.katman.set_overlay_pass_through(self.cizim, not acik)
        if not acik:
            self.silgi.set_active(False)
        self._dokunuldu()

    def _silgi_degisti(self, dugme):
        self.cizim.silgi = dugme.get_active()
        if dugme.get_active():
            self._kalemi_ac()

    def _renk_secildi(self, dugme, renk):
        if dugme.get_active():
            self.cizim.renk = renk
            self.silgi.set_active(False)
            self._kalemi_ac()

    # --- görüntü ---

    def _dondur_degisti(self, dugme):
        self.oynatici.dondur(dugme.get_active())
        self._rozeti_guncelle()

    def _yakinlastir(self, yon, oran=None):
        if oran is None:
            self.yakinlik = max(0, min(len(self.YAKINLIK) - 1, self.yakinlik + yon))
            oran = self.YAKINLIK[self.yakinlik]
        a = self.kaydirma.get_allocation()
        ha, va = self.kaydirma.get_hadjustment(), self.kaydirma.get_vadjustment()
        # Ekranın ortası yakınlaştırmadan sonra da ortada kalsın
        ox = (ha.get_value() + a.width / 2) / max(1, ha.get_upper())
        oy = (va.get_value() + a.height / 2) / max(1, va.get_upper())
        if oran <= 1.0:
            self.video.set_size_request(-1, -1)
        else:
            self.video.set_size_request(int(a.width * oran), int(a.height * oran))

        def ortala():
            ha.set_value(ox * ha.get_upper() - a.width / 2)
            va.set_value(oy * va.get_upper() - a.height / 2)
            return False
        GLib.timeout_add(50, ortala)
        self._dokunuldu()

    def _iki_parmak(self, _h, olcek):
        hedef = max(1.0, min(3.0, self.YAKINLIK[self.yakinlik] * olcek))
        self._yakinlastir(0, hedef)

    def _surukle_basla(self, hareket, _x, _y):
        self._surukle_baslangic = (self.kaydirma.get_hadjustment().get_value(),
                                   self.kaydirma.get_vadjustment().get_value())

    def _surukle_devam(self, _hareket, dx, dy):
        if self.yakinlik == 0 or self.kalem.get_active() or self.kontrol_acik:
            return
        h0, v0 = self._surukle_baslangic
        self.kaydirma.get_hadjustment().set_value(h0 - dx)
        self.kaydirma.get_vadjustment().set_value(v0 - dy)

    def kaydet(self):
        """Görüntü ve çizim birlikte Resimler/Tahtaya Yansıt klasörüne kaydedilir."""
        a = self.katman.get_allocation()
        yuzey = cairo.ImageSurface(cairo.FORMAT_RGB24, a.width, a.height)
        cr = cairo.Context(yuzey)
        self.kaydirma.draw(cr)
        self.cizim.draw(cr)
        klasor = os.path.join(GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_PICTURES)
                              or os.path.expanduser("~"), "Tahtaya Yansıt")
        try:
            os.makedirs(klasor, exist_ok=True)
            ad = time.strftime("%Y-%m-%d %H.%M.%S") + ".png"
            yuzey.write_to_png(os.path.join(klasor, ad))
            self.bildir(f"Kaydedildi: Resimler › Tahtaya Yansıt › {ad}")
        except OSError as e:
            self.bildir(f"Kaydedilemedi: {e}")

    def bildir(self, yazi, sure=3):
        self.bildirim.set_text(yazi)
        self.bildirim.show()
        if self.bildirim_zamanlayici:
            GLib.source_remove(self.bildirim_zamanlayici)

        def gizle():
            self.bildirim_zamanlayici = 0
            self.bildirim.hide()
            return False
        self.bildirim_zamanlayici = GLib.timeout_add_seconds(sure, gizle)

    def duraklatildi(self, evet):
        self.telefon_duraklatti = evet
        self._rozeti_guncelle()
        return False

    def _rozeti_guncelle(self):
        if self.dondur_dugmesi.get_active():
            self.rozet.set_text("Görüntü donduruldu")
        elif self.telefon_duraklatti:
            self.rozet.set_text("Öğretmen yansıtmayı duraklattı")
        else:
            self.rozet.hide()
            return
        self.rozet.show()

    def kalite(self, durum):
        """Telefonun bildirdiği kaliteye göre bağlantı göstergesi."""
        try:
            oran = float(durum.get("bit", 0)) / max(1.0, float(durum.get("en", 1)))
            atilan = int(durum.get("atilan", 0))
        except (TypeError, ValueError):
            return False
        if atilan > 0 or oran < 0.4:
            yazi, sinif = "● Bağlantı zayıf", "gosterge-zayif"
        elif oran < 0.75:
            yazi, sinif = "● Bağlantı orta", "gosterge-orta"
        else:
            yazi, sinif = "● Bağlantı iyi", "gosterge-iyi"
        stil = self.gosterge.get_style_context()
        for s in ("gosterge-iyi", "gosterge-orta", "gosterge-zayif"):
            stil.remove_class(s)
        stil.add_class(sinif)
        self.gosterge.set_text(yazi)
        return False

    # --- araç çubukları ---

    def _dokunuldu(self, *_):
        for r in (self.ust, self.arac, self.alt):
            r.set_reveal_child(True)
        if self.gizle_zamanlayici:
            GLib.source_remove(self.gizle_zamanlayici)
        self.gizle_zamanlayici = GLib.timeout_add_seconds(4, self._gizle)
        return False

    def _gizle(self):
        self.gizle_zamanlayici = 0
        self.ust.set_reveal_child(False)
        self.alt.set_reveal_child(False)
        if not self.kalem.get_active():  # çizerken araç çubuğu açık kalsın
            self.arac.set_reveal_child(False)
        return False

    def _tus(self, _p, olay):
        if olay.keyval == Gdk.KEY_Escape:
            self.bitir()
            return True
        return False

    def kapat(self):
        for z in (self.gizle_zamanlayici, self.bildirim_zamanlayici):
            if z:
                GLib.source_remove(z)
        self.destroy()


class QrAlani(Gtk.DrawingArea):
    """Telefonla okutulunca kod yazmadan eşleştiren QR kod."""

    def __init__(self, boyut=220):
        super().__init__()
        self.set_size_request(boyut, boyut)
        self.matris = None
        self.connect("draw", self._ciz)

    def ayarla(self, metin):
        self.matris = None
        if qrcode and metin:
            qr = qrcode.QRCode(border=2, error_correction=qrcode.constants.ERROR_CORRECT_M)
            qr.add_data(metin)
            qr.make(fit=True)
            self.matris = qr.get_matrix()
        self.set_visible(self.matris is not None)
        self.queue_draw()

    def _ciz(self, _w, cr):
        if not self.matris:
            return False
        a = self.get_allocation()
        n = len(self.matris)
        k = min(a.width, a.height) / n
        x0, y0 = (a.width - k * n) / 2, (a.height - k * n) / 2
        cr.set_source_rgb(1, 1, 1)
        cr.rectangle(x0, y0, k * n, k * n)
        cr.fill()
        cr.set_source_rgb(0.08, 0.13, 0.23)
        for i, satir in enumerate(self.matris):
            for j, dolu in enumerate(satir):
                if dolu:
                    cr.rectangle(x0 + j * k, y0 + i * k, k + 0.5, k + 0.5)
        cr.fill()
        return False


class BilgiPenceresi(Gtk.Window):
    """Tahta adı, adresi ve yeni cihaz tanıtma (kod + QR)."""

    def __init__(self, uygulama):
        super().__init__(title="Tahtaya Yansıt", application=uygulama)
        self.uyg = uygulama
        self.set_icon_name(SIMGE)
        self.set_default_size(700, -1)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.get_style_context().add_class("bilgi-penceresi")
        self.connect("delete-event", lambda *_: (self.hide(), True)[1])
        self.connect("hide", lambda *_: self._kodu_gizle())
        self.kapanma = 0
        self.geri_sayim = 0
        self.istek_adresi = None

        kutu = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16, margin=28)

        # Başlık: logo + ad
        ust = Gtk.Box(spacing=16)
        try:
            resim = Gtk.Image.new_from_pixbuf(
                GdkPixbuf.Pixbuf.new_from_file_at_scale(LOGO, 88, 88, True))
            ust.pack_start(resim, False, False, 0)
        except GLib.Error:
            pass
        yazilar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, valign=Gtk.Align.CENTER)
        yazilar.pack_start(sinifli(Gtk.Label(label="Tahtaya Yansıt", xalign=0), "uygulama-adi"),
                           False, False, 0)
        yazilar.pack_start(sinifli(Gtk.Label(label="Telefon ve tabletten tahtaya görüntü ve ses",
                                             xalign=0), "alt-baslik"), False, False, 0)
        ust.pack_start(yazilar, False, False, 0)
        kutu.pack_start(ust, False, False, 0)

        # İstek şeridi: "X tanıtılmak istiyor  [Kodu göster] [Reddet]"
        self.serit = sinifli(Gtk.Box(spacing=12), "istek")
        self.serit_yazi = sinifli(Gtk.Label(wrap=True, xalign=0, hexpand=True), "istek-yazi")
        self.serit.pack_start(self.serit_yazi, True, True, 0)
        self.serit_goster = sinifli(Gtk.Button(label="Kodu göster"), "cam-dugme")
        self.serit_goster.connect("clicked", lambda *_: self.kodu_goster())
        self.serit.pack_start(self.serit_goster, False, False, 0)
        self.serit_reddet = sinifli(Gtk.Button(label="Reddet"), "cam-dugme")
        self.serit_reddet.connect("clicked", self._reddet)
        self.serit.pack_start(self.serit_reddet, False, False, 0)
        kutu.pack_start(self.serit, False, False, 0)

        # Yeni cihaz kartı
        kod_karti = sinifli(Gtk.Box(spacing=24), "kart")
        sol = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, hexpand=True)
        sol.pack_start(sinifli(Gtk.Label(label="YENİ CİHAZ TANIT"), "baslik"), False, False, 0)
        self.pin = Gtk.Label(selectable=False)
        sol.pack_start(self.pin, False, False, 0)
        self.kod_aciklama = sinifli(Gtk.Label(wrap=True, justify=Gtk.Justification.CENTER), "bilgi")
        sol.pack_start(self.kod_aciklama, False, False, 0)
        self.kod_dugmesi = sinifli(Gtk.Button(label="Kodu göster"), "ana-dugme", "buyuk")
        self.kod_dugmesi.set_halign(Gtk.Align.CENTER)
        self.kod_dugmesi.connect("clicked", lambda *_: self.kodu_goster())
        self.kod_dugmesi.set_no_show_all(True)
        sol.pack_start(self.kod_dugmesi, False, False, 6)
        kod_karti.pack_start(sol, True, True, 0)
        self.qr = QrAlani()
        self.qr.set_no_show_all(True)
        kod_karti.pack_start(self.qr, False, False, 0)
        kutu.pack_start(kod_karti, False, False, 0)

        # Tahta adı kartı
        ad_karti = sinifli(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10), "kart")
        satir = Gtk.Box(spacing=10)
        satir.pack_start(sinifli(Gtk.Label(label="Tahtanın adı"), "bilgi"), False, False, 0)
        self.ad = sinifli(Gtk.Entry(hexpand=True, placeholder_text="Ör. 8-B Sınıfı"), "giris")
        self.ad.connect("activate", self._ad_kaydet)
        satir.pack_start(self.ad, True, True, 0)
        kaydet = sinifli(Gtk.Button(label="Kaydet"), "ana-dugme")
        kaydet.connect("clicked", self._ad_kaydet)
        satir.pack_start(kaydet, False, False, 0)
        ad_karti.pack_start(satir, False, False, 0)
        self.adres = sinifli(Gtk.Label(xalign=0, selectable=True), "soluk")
        ad_karti.pack_start(self.adres, False, False, 0)
        kutu.pack_start(ad_karti, False, False, 0)

        alt = Gtk.Box(spacing=8)
        self.unut = sinifli(Gtk.Button(), "cam-dugme")
        self.unut.connect("clicked", lambda *_: CihazlarPenceresi(self, self.uyg.ayarlar, self.yenile))
        alt.pack_start(self.unut, False, False, 0)
        sorun = sinifli(Gtk.Button(label="Sorun kaydını kaydet"), "cam-dugme")
        sorun.connect("clicked", self._sorun_kaydi)
        alt.pack_start(sorun, False, False, 0)
        kapat = sinifli(Gtk.Button(label="Kapat"), "cam-dugme")
        kapat.connect("clicked", lambda *_: self.hide())
        alt.pack_end(kapat, False, False, 0)
        kutu.pack_start(alt, False, False, 0)
        self.add(kutu)
        self._kodu_gizle()

    # --- kod ---

    def kodu_goster(self):
        """Tahtada biri dokundu: kod ve QR görünür, kod 2 dakika geçerli olur."""
        self.uyg.sunucu.eslesmeyi_ac()
        self.serit.hide()
        self.kalan = cekirdek.ESLESME_SURESI
        self.pin.get_style_context().remove_class("pin-gizli")
        self.pin.get_style_context().add_class("pin")
        self.pin.set_text(self.uyg.sunucu.pin)
        self.kod_dugmesi.hide()
        self.resize(700, 1)
        adresler = cekirdek.yerel_adresler()
        if adresler:
            sorgu = urllib.parse.urlencode({
                "a": adresler[0], "p": cekirdek.TCP_PORT, "i": self.uyg.ayarlar.id,
                "k": self.uyg.sunucu.pin, "n": self.uyg.ayarlar.ad})
            self.qr.ayarla(f"tahtayayansit://eslestir?{sorgu}")
        self._geri_say()
        if self.geri_sayim:
            GLib.source_remove(self.geri_sayim)
        self.geri_sayim = GLib.timeout_add_seconds(1, self._geri_say)
        if self.kapanma:
            GLib.source_remove(self.kapanma)
            self.kapanma = 0
        self.set_keep_above(True)
        one_getir(self)

    def _geri_say(self):
        if not self.uyg.sunucu.eslesme_acik():
            self._kodu_gizle()
            return False
        self.kalan = max(0, self.kalan - 1)
        self.kod_aciklama.set_text(
            "Telefonda Tahtaya Yansıt'ta bu tahtaya dokunup kodu girin"
            + (" ya da QR kodu okutun." if self.qr.get_visible() else ".")
            + f"\nKod {self.kalan // 60}:{self.kalan % 60:02d} boyunca geçerli.")
        return True

    def _kodu_gizle(self):
        if self.geri_sayim:
            GLib.source_remove(self.geri_sayim)
            self.geri_sayim = 0
        if self.uyg.sunucu:
            self.uyg.sunucu.eslesmeyi_kapat()
        self.pin.get_style_context().remove_class("pin")
        self.pin.get_style_context().add_class("pin-gizli")
        self.pin.set_text("••••")
        self.qr.ayarla(None)
        self.kod_aciklama.set_text("Yeni bir telefon ya da tablet tanıtmak için dokunun.\n"
                                   "Kod yalnızca tahtada görünür ve 2 dakika geçerlidir.")
        self.kod_dugmesi.show()
        self.set_keep_above(False)
        self.resize(700, 1)

    # --- pencere ---

    def yenile(self):
        self.uyg.ayarlar.guncelle()
        self.ad.set_text(self.uyg.ayarlar.ad)
        adresler = cekirdek.yerel_adresler()
        self.adres.set_text("Adres: " + (", ".join(adresler) if adresler else "ağ bağlantısı yok")
                            + f"   ·   Sürüm {cekirdek.paket_surumu()}")
        sayi = len(self.uyg.ayarlar.cihazlar)
        self.unut.set_label(f"Tanıtılmış cihazlar ({sayi})")
        return False

    def goster(self, mesaj="", sinif="istek", sure=0, istek_adresi=None):
        self.yenile()
        self.istek_adresi = istek_adresi
        for s in ("istek", "uyari"):
            self.serit.get_style_context().remove_class(s)
        self.serit.get_style_context().add_class(sinif)
        self.serit_yazi.set_text(mesaj)
        self.show_all()
        self.serit.set_visible(bool(mesaj))
        self.serit_goster.set_visible(istek_adresi is not None)
        self.serit_reddet.set_visible(istek_adresi is not None)
        self.set_keep_above(bool(sure) or self.uyg.sunucu.eslesme_acik())
        self.resize(700, 1)  # içerik azaldıysa pencere de küçülsün
        one_getir(self)
        if self.kapanma:
            GLib.source_remove(self.kapanma)
            self.kapanma = 0
        if sure:
            self.kapanma = GLib.timeout_add_seconds(sure, self._sure_doldu)
        return False

    def _sure_doldu(self):
        self.kapanma = 0
        if not self.uyg.sunucu.eslesme_acik():
            self.hide()
        return False

    def _reddet(self, *_):
        if self.istek_adresi:
            self.uyg.sunucu.reddet(self.istek_adresi)
        self.hide()

    def _ad_kaydet(self, *_):
        ad = self.ad.get_text().strip()
        if ad:
            self.uyg.ayarlar.ad = ad[:60]
            self.uyg.ayarlar.kaydet()
        self.yenile()

    def _sorun_kaydi(self, *_):
        """Kayıt dosyasını masaüstüne kopyalar; öğretmen geliştiriciye gönderebilir."""
        masaustu = (GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DESKTOP)
                    or os.path.expanduser("~"))
        hedef = os.path.join(masaustu, "Tahtaya Yansıt sorun kaydı.txt")
        try:
            with open(hedef, "wb") as f:
                f.write(f"Tahtaya Yansıt {cekirdek.paket_surumu()} · {self.uyg.ayarlar.ad}\n".encode())
                f.write(cekirdek.kayit_son(1_000_000))
            self.goster(f"Sorun kaydı masaüstüne kaydedildi: {os.path.basename(hedef)}", "istek", 0)
        except OSError as e:
            self.goster(f"Sorun kaydı kaydedilemedi: {e}", "uyari", 0)


class CihazlarPenceresi(Gtk.Window):
    """Tanıtılmış telefon ve tabletler; tek tek silinebilir."""

    def __init__(self, ust, ayarlar, degisti):
        super().__init__(title="Tanıtılmış cihazlar")
        self.ayarlar = ayarlar
        self.degisti = degisti
        self.set_transient_for(ust)
        self.set_modal(True)
        self.set_default_size(560, -1)
        self.set_position(Gtk.WindowPosition.CENTER_ON_PARENT)
        self.get_style_context().add_class("bilgi-penceresi")
        self.kutu = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin=24)
        self.add(self.kutu)
        self.doldur()
        self.show_all()

    def doldur(self):
        for c in self.kutu.get_children():
            self.kutu.remove(c)
        self.kutu.pack_start(sinifli(Gtk.Label(label="Tanıtılmış cihazlar", xalign=0), "uygulama-adi"),
                             False, False, 0)
        cihazlar = sorted(self.ayarlar.cihazlar.items(), key=lambda t: t[1].get("tarih", ""), reverse=True)
        if not cihazlar:
            self.kutu.pack_start(sinifli(Gtk.Label(label="Henüz tanıtılmış cihaz yok.", xalign=0),
                                         "bilgi"), False, False, 0)
        for token, bilgi in cihazlar:
            satir = sinifli(Gtk.Box(spacing=12), "kart")
            yazilar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, hexpand=True)
            yazilar.pack_start(sinifli(Gtk.Label(label=bilgi.get("ad", "?"), xalign=0), "bilgi"),
                               False, False, 0)
            yazilar.pack_start(sinifli(Gtk.Label(label=f"Tanıtıldı: {bilgi.get('tarih', '?')}", xalign=0),
                                       "soluk"), False, False, 0)
            satir.pack_start(yazilar, True, True, 0)
            sil = sinifli(Gtk.Button(label="Sil"), "cam-dugme")
            sil.connect("clicked", self._sil, token)
            satir.pack_start(sil, False, False, 0)
            self.kutu.pack_start(satir, False, False, 0)
        alt = Gtk.Box(spacing=8)
        if cihazlar:
            hepsi = sinifli(Gtk.Button(label="Hepsini unut"), "cam-dugme")
            hepsi.connect("clicked", self._hepsi)
            alt.pack_start(hepsi, False, False, 0)
        kapat = sinifli(Gtk.Button(label="Kapat"), "ana-dugme")
        kapat.connect("clicked", lambda *_: self.destroy())
        alt.pack_end(kapat, False, False, 0)
        self.kutu.pack_start(alt, False, False, 6)
        self.kutu.show_all()
        self.resize(560, 1)

    def _sil(self, _d, token):
        self.ayarlar.cihaz_sil(token)
        self.degisti()
        self.doldur()

    def _hepsi(self, _d):
        self.ayarlar.cihazlari_unut()
        self.degisti()
        self.doldur()


class DevirSorusu(Gtk.Window):
    """Yansıtma sürerken başka bir cihaz devralmak isterse tahtada sorulur."""

    def __init__(self, ust, yeni, mevcut, cevap):
        super().__init__(title="Tahtaya Yansıt")
        self.cevap = cevap
        self.verildi = False
        self.get_style_context().add_class("bilgi-penceresi")
        if ust:
            self.set_transient_for(ust)
        self.set_modal(True)
        self.set_keep_above(True)
        self.set_position(Gtk.WindowPosition.CENTER_ALWAYS)
        self.set_decorated(False)
        kutu = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18, margin=32)
        kutu.pack_start(sinifli(Gtk.Label(label=f"“{yeni}” yansıtmak istiyor"), "uygulama-adi"),
                        False, False, 0)
        kutu.pack_start(sinifli(Gtk.Label(
            label=f"Şu an “{mevcut}” yansıtıyor. İzin verirseniz ekran yeni cihaza geçer."),
            "bilgi"), False, False, 0)
        satir = Gtk.Box(spacing=12, halign=Gtk.Align.CENTER)
        reddet = sinifli(Gtk.Button(label="Reddet"), "cam-dugme", "buyuk")
        reddet.connect("clicked", lambda *_: self._bitir(False))
        izin = sinifli(Gtk.Button(label="İzin ver"), "ana-dugme", "buyuk")
        izin.connect("clicked", lambda *_: self._bitir(True))
        satir.pack_start(reddet, False, False, 0)
        satir.pack_start(izin, False, False, 0)
        kutu.pack_start(satir, False, False, 0)
        self.add(kutu)
        self.connect("delete-event", lambda *_: (self._bitir(False), True)[1])
        self.zaman = GLib.timeout_add_seconds(cekirdek.DEVIR_SURESI, self._zaman_doldu)
        self.show_all()
        one_getir(self)

    def _zaman_doldu(self):
        self.zaman = 0
        self._bitir(False)
        return False

    def _bitir(self, izin):
        if self.verildi:
            return
        self.verildi = True
        if self.zaman:
            GLib.source_remove(self.zaman)
            self.zaman = 0
        self.cevap(izin)
        self.destroy()


class Uygulama(Gtk.Application, cekirdek.Olaylar):
    def __init__(self):
        super().__init__(application_id=UYGULAMA_KIMLIGI,
                         flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.ayarlar = None
        self.sunucu = None
        self.bilgi = None
        self.oynatici = None
        self.yayin = None
        self.oturum = None

    # --- Gtk.Application ---

    def do_startup(self):
        Gtk.Application.do_startup(self)
        cekirdek.kayit_kur()
        cekirdek.kayit.info("Tahtaya Yansıt %s başladı", cekirdek.paket_surumu())
        Gst.init(None)
        saglayici = Gtk.CssProvider()
        try:
            saglayici.load_from_data(CSS)
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(), saglayici, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        except GLib.Error as hata:
            cekirdek.kayit.warning("Görünüm yüklenemedi: %s", hata)
        self.ayarlar = cekirdek.Ayarlar()
        try:
            self.sunucu = cekirdek.Sunucu(self.ayarlar, self)
            self.kesif = cekirdek.Kesif(self.ayarlar)
        except OSError as hata:
            cekirdek.kayit.error("Bağlantı noktası açılamadı (başka bir oturumda çalışıyor olabilir): %s",
                                 hata)
            self.quit()
            return
        self.sunucu.start()
        self.kesif.start()
        self.bilgi = BilgiPenceresi(self)
        self.hold()  # Pencere kapalıyken de arka planda dinlemeye devam et.

    def do_command_line(self, komut):
        if self.bilgi is None:
            return 1
        if "--arka-plan" not in komut.get_arguments()[1:]:
            self.bilgi.goster()
        return 0

    # --- cekirdek.Olaylar (ağ iş parçacığından gelir) ---

    def eslesme_istegi(self, cihaz_adi, adres):
        mesaj = f"“{cihaz_adi}” bu tahtaya tanıtılmak istiyor."
        GLib.idle_add(self.bilgi.goster, mesaj, "istek", 120, adres)

    def yanlis_kod(self, cihaz_adi):
        GLib.idle_add(self.bilgi.goster, f"“{cihaz_adi}” yanlış kod girdi.", "uyari", 0)

    def eslesme_kapandi(self):
        GLib.idle_add(self.bilgi.goster,
                      "Çok fazla yanlış deneme yapıldı; kod iptal edildi. Gerekirse yeniden "
                      "“Kodu göster”e dokunun.", "uyari", 60)

    def cihaz_tanitildi(self, _cihaz_adi):
        GLib.idle_add(self.bilgi.hide)

    def devir_sor(self, yeni_cihaz, mevcut_cihaz):
        sonuc = {"izin": False}
        bitti = threading.Event()

        def cevap(izin):
            sonuc["izin"] = izin
            bitti.set()

        def sor():
            DevirSorusu(self.yayin, yeni_cihaz, mevcut_cihaz, cevap)
            return False

        GLib.idle_add(sor)
        bitti.wait(cekirdek.DEVIR_SURESI + 5)
        return sonuc["izin"]

    def yayin_basladi(self, oturum):
        hazir = threading.Event()

        def kur():
            try:
                self._yayini_kur(oturum)
            finally:
                hazir.set()
            return False

        GLib.idle_add(kur)
        hazir.wait(10)

    def kare(self, oturum, tur, bayrak, _zaman, veri):
        if self.oturum is not oturum:
            return
        if tur == cekirdek.T_DURUM:
            if self.yayin and bayrak & 4:
                try:
                    GLib.idle_add(self.yayin.kontrol_durumu, json.loads(veri.decode("utf-8")))
                except ValueError:
                    pass
            elif self.yayin and bayrak & 2:
                try:
                    GLib.idle_add(self.yayin.kalite, json.loads(veri.decode("utf-8")))
                except ValueError:
                    pass
            elif self.yayin:
                GLib.idle_add(self.yayin.duraklatildi, bool(bayrak & 1))
            return
        oynatici = self.oynatici
        if oynatici:
            oynatici.kare(tur, bayrak, veri)

    def yayin_bitti(self, oturum):
        GLib.idle_add(self._yayini_kapat, oturum)

    # --- yayın ---

    def _yayini_kur(self, oturum):
        self._yayini_kapat(self.oturum)
        self.bilgi.hide()
        try:
            oynatici = Oynatici(oturum.ses, self._oynatma_hatasi)
        except GLib.Error as hata:
            self._oynatma_hatasi(str(hata))
            oturum.kapat()
            return
        self.yayin = YayinPenceresi(oynatici, oturum.cihaz_adi, self.sunucu.yayini_bitir,
                                    dokun=oturum.dokunma)
        self.oynatici = oynatici
        self.oturum = oturum
        if not oynatici.baslat():
            self._oynatma_hatasi("oynatıcı başlatılamadı")

    def _yayini_kapat(self, oturum):
        if oturum is None or oturum is not self.oturum:
            return False
        self.oturum = None
        if self.oynatici:
            self.oynatici.durdur()
            self.oynatici = None
        if self.yayin:
            self.yayin.kapat()
            self.yayin = None
        return False

    def _oynatma_hatasi(self, mesaj):
        def goster():
            oturum = self.oturum
            if oturum and self.oynatici and self.oynatici.cozucu != "avdec_h264":
                # Ekran kartıyla çözme bu tahtada çalışmadı; işlemciyle çöz.
                cekirdek.kayit.warning("Ekran kartıyla çözme olmadı (%s); işlemciye geçiliyor", mesaj)
                os.environ["YANSITICI_DONANIM"] = "0"
            elif oturum and os.environ.get("YANSITICI_GL", "1") != "0":
                # GL çizimi bu tahtada çalışmadı; yazılım çizimiyle yeniden kur.
                cekirdek.kayit.warning("GL çizimi olmadı (%s); yazılım çizimine geçiliyor", mesaj)
                os.environ["YANSITICI_GL"] = "0"
            else:
                self.bilgi.goster("Görüntü oynatılamadı: " + mesaj, "uyari", 30)
                return False
            self._yayini_kapat(oturum)
            self._yayini_kur(oturum)
            return False
        GLib.idle_add(goster)


def main():
    # BT sorumlusu için arayüzsüz komutlar: tahtaya ad verme, sürüm
    if "--ad" in sys.argv:
        i = sys.argv.index("--ad")
        if i + 1 >= len(sys.argv) or not sys.argv[i + 1].strip():
            print('Kullanım: tahtaya-yansit --ad "8-B Sınıfı"', file=sys.stderr)
            return 2
        ayarlar = cekirdek.Ayarlar()
        ayarlar.ad = sys.argv[i + 1].strip()[:60]
        ayarlar.kaydet()
        print(f"Tahtanın adı: {ayarlar.ad}  ({ayarlar.dosya})")
        return 0
    if "--surum" in sys.argv:
        print(cekirdek.paket_surumu())
        return 0
    return Uygulama().run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
