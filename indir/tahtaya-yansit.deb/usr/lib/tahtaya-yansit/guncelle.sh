#!/bin/sh
# Tahtaya Yansıt'ı kendi deposundan günceller (yalnızca bu paketi; sistemin geri kalanına dokunmaz).
# tahtaya-yansit-guncelle.timer tarafından açılıştan 15 dk sonra ve 6 saatte bir çalıştırılır.
LISTE=/etc/apt/sources.list.d/tahtaya-yansit.list
[ -f "$LISTE" ] || exit 0

# Yansıtma sürerken güncelleme yapma: uygulama yeniden başlar, ders kesilir.
if command -v ss >/dev/null 2>&1 && ss -Htn state established '( sport = :48101 )' 2>/dev/null | grep -q .; then
    echo "Yansıtma sürüyor; güncelleme sonraya kaldı."
    exit 0
fi

# Yalnızca bu deponun listesini yenile (diğer depoların listeleri silinmez).
apt-get update -qq -o Dir::Etc::sourcelist="$LISTE" -o Dir::Etc::sourceparts="-" \
    -o APT::Get::List-Cleanup="0" || exit 0

kurulu=$(dpkg-query -W -f='${Version}' tahtaya-yansit 2>/dev/null)
aday=$(LC_ALL=C apt-cache policy tahtaya-yansit 2>/dev/null | awk '/Candidate:/ {print $2; exit}')
if [ -n "$aday" ] && [ "$aday" != "$kurulu" ] && dpkg --compare-versions "$aday" gt "$kurulu"; then
    echo "Güncelleniyor: $kurulu → $aday"
    DEBIAN_FRONTEND=noninteractive apt-get install --only-upgrade -y -qq \
        -o Dpkg::Options::=--force-confold tahtaya-yansit
else
    echo "Güncel: $kurulu"
fi
