"""Tahtaya Yansıt — ağ çekirdeği (arayüzden bağımsız).

Telefon ile tahta arasındaki protokol (sürüm 2):

Keşif (UDP 48100): telefon yayına "TAHTAYA-YANSIT-ARA" gönderir, tahta
kendi adresine JSON ile cevap verir: {"uygulama", "v", "surum", "id", "ad", "port"}.

Bağlantı (TCP 48101): telefon tek satır JSON gönderir:
    {"tur": "yokla" | "yayin", "v": 2, "cihaz": "...", "token": "...",
     "pin": "1234", "ses": true}
Tahta tek satır JSON ile cevap verir:
    {"ok": true, "id", "ad", "surum", "token"?, "mesgul"?}
    {"ok": false, "neden": "pin", "yanlis": bool, "eslesme_acik": bool}
    {"ok": false, "neden": "mesgul" | "reddedildi" | "surum"}
"yokla" cevaptan sonra kapanır. "kayit" cevaptan sonra tahtanın kayıt dosyasını
gönderip kapanır (sorun bildirmek için). "yayin" ise ardından ikili kareler gelir:
    tür (1 bayt) | bayrak (1 bayt) | zaman µs (8 bayt) | uzunluk (4 bayt) | veri
Yayın sırasında tahta telefona tek baytlık işaretler yollar ("ping": true):
    P: tahta yerinde (2 sn'de bir) · B: tahtada "Yansıtmayı bitir"e basıldı
    D: yansıtma başka cihaza devredildi
P gelmezse telefon bağlantının koptuğunu anlar ve yeniden bağlanır; B ya da D
gelirse yeniden bağlanmaz.
Telefon el sıkışmada "kontrol": true derse tahta dokunuşları da yollayabilir:
    G | eylem (1 bayt: 0 bas, 1 sürükle, 2 bırak) | x (2 bayt) | y (2 bayt)
x, y telefon ekranında 0–65535 arası oran. Telefon izin durumunu T_DURUM
bayrak 4 ile JSON olarak bildirir: {"izin": bool, "uyari": "..."}.

Tahtayı tabletten kontrol ("tur": "izle", yalnızca tanıtılmış cihaz): tahta kendi
ekranını aynı kare biçimiyle (T_VIDEO) tablete yollar; tablet T_GIRDI kareleriyle
dokunuş gönderir (veri: eylem, x, y — DOKUNMA biçimi; eylem 3/4: yukarı/aşağı kaydır).
Cevap: {"ok": true, "genislik", "yukseklik", "girdi": bool} ya da
{"ok": false, "neden": "desteklenmiyor" | "kodlayici"}.

Güvenlik: Kod yalnızca tahtada biri "Kodu göster" / "Yeni cihaz tanıt"a
dokunduğunda geçerlidir (eşleşme penceresi). Tanıtılmış başka bir cihaz
yansıtmayı devralmak isterse tahtada onay istenir.
"""

import json
import logging
import logging.handlers
import os
import secrets
import socket
import struct
import threading
import time
import uuid

UDP_PORT = 48100
TCP_PORT = 48101
PROTOKOL = 2
ARA_MESAJI = b"TAHTAYA-YANSIT-ARA"

BASLIK = struct.Struct(">BBqI")
T_VIDEO_AYAR = 1
T_VIDEO = 2
T_SES = 4
T_PING = 5
T_DURUM = 6  # bayrak 1: telefon duraklattı, 0: devam
T_GIRDI = 7  # tabletten tahtaya dokunuş (tahtayı tabletten kontrol)
T_BITIR = 9
B_ANAHTAR = 1

K_PING = b"P"
K_BITIR = b"B"
K_DEVIR = b"D"
K_DOKUNMA = b"G"
DOKUNMA = struct.Struct(">BHH")
D_BAS, D_SURUKLE, D_BIRAK = 0, 1, 2
D_KAYDIR_YUKARI, D_KAYDIR_ASAGI = 3, 4
PING_ARALIGI = 2

EN_BUYUK_KARE = 16 * 1024 * 1024
YANLIS_KOD_SINIRI = 5       # bir eşleşme penceresinde en fazla bu kadar yanlış deneme
ESLESME_SURESI = 120        # "Kodu göster"den sonra kodun geçerli kaldığı saniye
ISTEK_ARALIGI = 20          # aynı adresten iki eşleşme isteği arasındaki en kısa süre
RED_SURESI = 300            # tahtada "Reddet" denen adres bu kadar saniye engellenir
DEVIR_SURESI = 30           # devralma onayı için tahtada beklenen en uzun süre

kayit = logging.getLogger("tahtaya-yansit")

ORTAK_KLASOR = "/var/lib/tahtaya-yansit"
# Testlerde yalnızca bu bilgisayardan bağlantı kabul etmek için (ör. 127.0.0.1); normalde bütün ağ.
DINLE = os.environ.get("TAHTAYA_YANSIT_DINLE", "")


def dokunma_cevir(x, y, genislik, yukseklik, kare_g, kare_y, yon):
    """Tahtadaki görüntü alanında (genislik×yukseklik) dokunulan noktayı telefon ekranında 0–1 orana çevirir.

    Görüntü alana oranı korunarak ortalanır (kenarlarda siyah boşluk); kare_g×kare_y ekrandaki (döndürülmüş)
    karenin boyutu, yon tahtadaki döndürme (0, 1=90° saat yönü, 2=180°, 3=90° ters). Boşluğa dokunulduysa None.
    """
    if genislik <= 0 or yukseklik <= 0 or kare_g <= 0 or kare_y <= 0:
        return None
    olcek = min(genislik / kare_g, yukseklik / kare_y)
    g, h = kare_g * olcek, kare_y * olcek
    u = (x - (genislik - g) / 2) / g
    v = (y - (yukseklik - h) / 2) / h
    if not (0 <= u <= 1 and 0 <= v <= 1):
        return None
    if yon == 1:      # saat yönünde döndürülmüş: telefonun sol kenarı tahtada üstte
        return v, 1 - u
    if yon == 2:
        return 1 - u, 1 - v
    if yon == 3:
        return 1 - v, u
    return u, v


def kullanici_klasoru():
    taban = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(taban, "tahtaya-yansit")


def ayar_klasoru():
    """Ayarlar bütün kullanıcılar için ortak tutulur (kurulum paketi klasörü yazılabilir yapar)."""
    if os.path.isdir(ORTAK_KLASOR) and os.access(ORTAK_KLASOR, os.W_OK):
        return ORTAK_KLASOR
    return kullanici_klasoru()


def kayit_dosyasi():
    return os.path.join(ayar_klasoru(), "kayit.log")


def kayit_kur():
    """Olaylar kayit.log'a yazılır (sorun bildirirken telefona gönderilir)."""
    kayit.setLevel(logging.INFO)
    try:
        os.makedirs(ayar_klasoru(), exist_ok=True)
        dosya = logging.handlers.RotatingFileHandler(kayit_dosyasi(), maxBytes=300_000,
                                                     backupCount=1, encoding="utf-8")
        dosya.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        kayit.addHandler(dosya)
        try:
            os.chmod(kayit_dosyasi(), 0o666)
        except OSError:
            pass
    except OSError:
        pass
    kayit.addHandler(logging.StreamHandler())


def kayit_son(bayt=200_000):
    try:
        with open(kayit_dosyasi(), "rb") as f:
            f.seek(0, os.SEEK_END)
            f.seek(max(0, f.tell() - bayt))
            return f.read()
    except OSError:
        return b"(kayit dosyasi yok)\n"


def paket_surumu():
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "surum.txt"),
                  encoding="utf-8") as f:
            return f.read().strip() or "0"
    except OSError:
        return "0"


class Ayarlar:
    """Tahta adı, kimliği ve daha önce kod girilerek tanıtılmış cihazlar."""

    def __init__(self, klasor=None):
        self.klasor = klasor or ayar_klasoru()
        self.dosya = os.path.join(self.klasor, "ayarlar.json")
        self.kilit = threading.Lock()
        veri = self._oku(self.dosya)
        if not veri and klasor is None and self.klasor != kullanici_klasoru():
            # Eski sürümler ayarları kullanıcının klasöründe tutuyordu; onları devral.
            veri = self._oku(os.path.join(kullanici_klasoru(), "ayarlar.json"))
        self.id = veri.get("id") or uuid.uuid4().hex
        self.ad = veri.get("ad") or socket.gethostname()
        self.cihazlar = veri.get("cihazlar") or {}
        self._zaman = None
        self.kaydet()

    def _dosya_zamani(self):
        try:
            return os.stat(self.dosya).st_mtime_ns
        except OSError:
            return None

    def guncelle(self):
        """Dosya başka bir yerden değiştiyse (ör. BT sorumlusu `tahtaya-yansit --ad` çalıştırdı) yeniden oku."""
        zaman = self._dosya_zamani()
        if zaman is None or zaman == self._zaman:
            return
        veri = self._oku(self.dosya)
        if veri:
            self.id = veri.get("id") or self.id
            self.ad = veri.get("ad") or self.ad
            self.cihazlar = veri.get("cihazlar") or {}
        self._zaman = zaman

    @staticmethod
    def _oku(dosya):
        try:
            with open(dosya, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return {}

    def kaydet(self):
        with self.kilit:
            try:
                os.makedirs(self.klasor, exist_ok=True)
                gecici = f"{self.dosya}.{os.getpid()}.tmp"
                with open(gecici, "w", encoding="utf-8") as f:
                    json.dump({"id": self.id, "ad": self.ad, "cihazlar": self.cihazlar},
                              f, ensure_ascii=False, indent=1)
                try:
                    os.chmod(gecici, 0o666)  # tahtadaki diğer öğretmen hesapları da yazabilsin
                except OSError:
                    pass
                os.replace(gecici, self.dosya)
                self._zaman = self._dosya_zamani()
            except OSError:
                pass

    def cihaz_ekle(self, cihaz_adi):
        self.guncelle()
        token = secrets.token_hex(16)
        self.cihazlar[token] = {"ad": cihaz_adi, "tarih": time.strftime("%Y-%m-%d %H:%M")}
        self.kaydet()
        return token

    def cihaz_sil(self, token):
        self.guncelle()
        if self.cihazlar.pop(token, None) is not None:
            self.kaydet()

    def cihazlari_unut(self):
        self.guncelle()
        self.cihazlar = {}
        self.kaydet()


def yeni_pin():
    return f"{secrets.randbelow(10000):04d}"


def yerel_adresler():
    """Tahtanın ağdaki IPv4 adresleri (ekranda göstermek için)."""
    adresler = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        adresler.append(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for bilgi in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = bilgi[4][0]
            if not ip.startswith("127.") and ip not in adresler:
                adresler.append(ip)
    except OSError:
        pass
    return adresler


def tam_oku(sok, n):
    parcalar = []
    while n:
        p = sok.recv(min(n, 1 << 20))
        if not p:
            raise ConnectionError("bağlantı kapandı")
        parcalar.append(p)
        n -= len(p)
    return b"".join(parcalar)


def satir_oku(sok, sinir=8192):
    veri = b""
    while not veri.endswith(b"\n"):
        p = sok.recv(1)
        if not p:
            raise ConnectionError("bağlantı kapandı")
        veri += p
        if len(veri) > sinir:
            raise ValueError("satır çok uzun")
    return json.loads(veri.decode("utf-8"))


def satir_yaz(sok, nesne):
    sok.sendall(json.dumps(nesne, ensure_ascii=False).encode("utf-8") + b"\n")


class Olaylar:
    """Arayüzün dolduracağı geri çağrılar. Hepsi ağ iş parçacığından çağrılır."""

    def eslesme_istegi(self, cihaz_adi, adres):
        """Tanıtılmamış bir cihaz bağlanmak istiyor; tahtada "Kodu göster / Reddet" sorulur."""

    def yanlis_kod(self, cihaz_adi):
        pass

    def eslesme_kapandi(self):
        """Kod yenilendi ya da süresi doldu."""

    def cihaz_tanitildi(self, cihaz_adi):
        pass

    def devir_sor(self, yeni_cihaz, mevcut_cihaz):
        """Başka cihaz yansıtırken yeni cihaz devralmak istiyor. True: izin ver."""
        return False

    def yayin_basladi(self, oturum):
        pass

    def kare(self, oturum, tur, bayrak, zaman, veri):
        pass

    def yayin_bitti(self, oturum):
        pass

    def izleme_istegi(self, oturum):
        """Tanıtılmış bir cihaz tahtayı izleyip kontrol etmek istiyor.
        (True, {"genislik", "yukseklik", "girdi"}) ya da (False, neden) döndürür."""
        return False, "desteklenmiyor"

    def girdi(self, oturum, eylem, u, v):
        """Tabletten gelen dokunuş (u, v: tahta ekranında 0–1)."""

    def izleme_bitti(self, oturum):
        pass


class IzlemeOturumu:
    """Tahtanın ekranını izleyen/kontrol eden cihaz."""

    def __init__(self, sok, adres, cihaz_adi, token):
        self.sok = sok
        self.adres = adres
        self.cihaz_adi = cihaz_adi
        self.token = token
        self.yazma = threading.Lock()
        self.kapali = threading.Event()
        self.hazir = threading.Event()  # cevap satırı gitmeden kare gönderilmez

    def gonder(self, tur, bayrak, veri, zaman=0):
        if self.kapali.is_set() or not self.hazir.is_set():
            return False
        try:
            with self.yazma:
                self.sok.sendall(BASLIK.pack(tur, bayrak, zaman, len(veri)) + veri)
            return True
        except OSError:
            self.kapat()
            return False

    def kapat(self):
        if self.kapali.is_set():
            return
        self.kapali.set()
        try:
            self.sok.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            self.sok.close()
        except OSError:
            pass


class Oturum:
    def __init__(self, sok, adres, cihaz_adi, ses, token, kontrol=False):
        self.kontrol = kontrol  # telefon tahtadan dokunuş alabiliyor mu
        self.sok = sok
        self.adres = adres
        self.cihaz_adi = cihaz_adi
        self.ses = ses
        self.token = token
        self.yazma = threading.Lock()
        self.kapali = threading.Event()
        self.neden = None  # tahta tarafından kapatıldıysa kayıtta görünecek neden

    def isaret(self, bayt):
        """Telefona tek baytlık işaret (P/B/D) yollar."""
        try:
            with self.yazma:
                self.sok.sendall(bayt)
            return True
        except OSError:
            return False

    def dokunma(self, eylem, u, v):
        """Tahtadaki dokunuşu telefona yollar (u, v: telefon ekranında 0–1)."""
        if not self.kontrol or self.kapali.is_set():
            return False
        x = max(0, min(65535, round(u * 65535)))
        y = max(0, min(65535, round(v * 65535)))
        return self.isaret(K_DOKUNMA + DOKUNMA.pack(eylem, x, y))

    def ping_baslat(self):
        def dongu():
            while not self.kapali.wait(PING_ARALIGI):
                if not self.isaret(K_PING):
                    return
        threading.Thread(target=dongu, daemon=True).start()

    def kapat(self, isaret=None):
        """isaret: kapanırken telefona yollanacak neden (K_BITIR / K_DEVIR)."""
        if self.kapali.is_set():
            return
        self.kapali.set()
        if self.neden is None:
            self.neden = {K_BITIR: "tahtadan bitirildi", K_DEVIR: "başka cihaza devredildi"}.get(isaret)
        if isaret:
            self.isaret(isaret)
        try:
            self.sok.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            self.sok.close()
        except OSError:
            pass


class Kesif(threading.Thread):
    """Telefonların arama mesajlarına cevap verir."""

    def __init__(self, ayarlar, port=UDP_PORT, tcp_port=TCP_PORT):
        super().__init__(daemon=True)
        self.ayarlar = ayarlar
        self.tcp_port = tcp_port
        self.surum = paket_surumu()
        self.sok = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sok.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sok.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        self.sok.bind((DINLE, port))

    def run(self):
        while True:
            try:
                veri, adres = self.sok.recvfrom(512)
            except OSError:
                return
            if not veri.startswith(ARA_MESAJI):
                continue
            self.ayarlar.guncelle()
            cevap = {"uygulama": "tahtaya-yansit", "v": PROTOKOL, "surum": self.surum,
                     "id": self.ayarlar.id, "ad": self.ayarlar.ad, "port": self.tcp_port}
            try:
                self.sok.sendto(json.dumps(cevap, ensure_ascii=False).encode("utf-8"), adres)
            except OSError:
                pass

    def kapat(self):
        self.sok.close()


class Sunucu(threading.Thread):
    def __init__(self, ayarlar, olaylar, port=TCP_PORT):
        super().__init__(daemon=True)
        self.ayarlar = ayarlar
        self.olaylar = olaylar
        self.surum = paket_surumu()
        self.pin = yeni_pin()
        self.kilit = threading.Lock()
        self.eslesme_bitis = 0.0
        self.yanlis_sayisi = 0
        self.engelli = {}       # ip -> engelin bittiği an
        self.son_istek = {}     # ip -> son eşleşme isteği anı
        self.aktif = None
        self.izleyen = None
        self.sok = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sok.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sok.bind((DINLE, port))
        self.sok.listen(8)

    # --- arayüzden çağrılır ---

    def eslesmeyi_ac(self, sure=ESLESME_SURESI):
        """Tahtada kod gösterildi; kod bu süre boyunca kabul edilir."""
        with self.kilit:
            self.eslesme_bitis = time.monotonic() + sure
            self.yanlis_sayisi = 0

    def eslesmeyi_kapat(self):
        with self.kilit:
            self._eslesmeyi_kapat()

    def _eslesmeyi_kapat(self):
        if self.eslesme_bitis:
            self.eslesme_bitis = 0.0
            self.pin = yeni_pin()  # gösterilmiş kod bir daha kullanılamasın

    def eslesme_acik(self):
        with self.kilit:
            return time.monotonic() < self.eslesme_bitis

    def reddet(self, adres):
        with self.kilit:
            self.engelli[adres] = time.monotonic() + RED_SURESI

    def yayini_bitir(self):
        with self.kilit:
            oturum = self.aktif
        if oturum:
            kayit.info("Yansıtma tahtadan bitirildi: %s", oturum.cihaz_adi)
            oturum.kapat(K_BITIR)

    def izlemeyi_bitir(self):
        with self.kilit:
            oturum = self.izleyen
        if oturum:
            kayit.info("Tahtanın kontrolü tahtadan kesildi: %s", oturum.cihaz_adi)
            oturum.kapat()

    def run(self):
        while True:
            try:
                sok, adres = self.sok.accept()
            except OSError:
                return
            threading.Thread(target=self._baglanti, args=(sok, adres), daemon=True).start()

    def kapat(self):
        self.sok.close()
        if self.aktif:
            self.aktif.kapat()

    # --- kimlik denetimi ---

    def _kod_dene(self, pin):
        """(dogru, eslesme_acik). Yanlış denemeler sayılır; sınır aşılınca eşleşme kapanır."""
        with self.kilit:
            acik = time.monotonic() < self.eslesme_bitis
            if not acik:
                return False, False
            if secrets.compare_digest(pin, self.pin):
                self._eslesmeyi_kapat()
                return True, True
            self.yanlis_sayisi += 1
            if self.yanlis_sayisi >= YANLIS_KOD_SINIRI:
                # Tahmin denemelerine karşı: kod yenilenir, tahtada yeniden dokunmak gerekir.
                self._eslesmeyi_kapat()
                kapandi = True
            else:
                kapandi = False
        if kapandi:
            self.olaylar.eslesme_kapandi()
        return False, not kapandi

    def _istek_gosterilsin_mi(self, ip):
        simdi = time.monotonic()
        with self.kilit:
            if self.engelli.get(ip, 0) > simdi:
                return "engelli"
            if simdi - self.son_istek.get(ip, -ISTEK_ARALIGI) < ISTEK_ARALIGI:
                return "yakin"
            self.son_istek[ip] = simdi
            return "goster"

    def _cevap_temeli(self):
        return {"id": self.ayarlar.id, "ad": self.ayarlar.ad, "surum": self.surum, "v": PROTOKOL,
                "ping": True}

    def _baglanti(self, sok, adres):
        sok.settimeout(15)
        ip = adres[0]
        try:
            istek = satir_oku(sok)
            cihaz = str(istek.get("cihaz") or "Bilinmeyen cihaz")[:80]
            self.ayarlar.guncelle()
            temel = self._cevap_temeli()
            try:
                v = int(istek.get("v") or 1)
            except (TypeError, ValueError):
                v = 1
            if v != PROTOKOL:
                kayit.warning("Uyumsuz protokol %s: %s (%s)", v, cihaz, ip)
                satir_yaz(sok, dict(temel, ok=False, neden="surum"))
                return sok.close()

            token = str(istek.get("token") or "")
            pin = str(istek.get("pin") or "")
            if not (token and token in self.ayarlar.cihazlar):
                token = ""
                if pin:
                    dogru, acik = self._kod_dene(pin)
                    if not dogru:
                        time.sleep(1)
                        if acik:
                            self.olaylar.yanlis_kod(cihaz)
                        elif self.aktif is None and self._istek_gosterilsin_mi(ip) == "goster":
                            # Kodun süresi dolmuş; tahtada yeniden "Kodu göster" sorulsun.
                            self.olaylar.eslesme_istegi(cihaz, ip)
                        satir_yaz(sok, dict(temel, ok=False, neden="pin", yanlis=True,
                                            eslesme_acik=acik))
                        return sok.close()
                    token = self.ayarlar.cihaz_ekle(cihaz)
                    kayit.info("Yeni cihaz tanıtıldı: %s (%s)", cihaz, ip)
                    self.olaylar.cihaz_tanitildi(cihaz)
                    yeni_token = token
                else:
                    if self.aktif is not None:
                        # Yansıtma sürerken tahtada pencere açıp dersi bölmeyelim.
                        satir_yaz(sok, dict(temel, ok=False, neden="mesgul"))
                        return sok.close()
                    durum = self._istek_gosterilsin_mi(ip)
                    if durum == "engelli":
                        satir_yaz(sok, dict(temel, ok=False, neden="reddedildi"))
                        return sok.close()
                    if durum == "goster" and not self.eslesme_acik():
                        kayit.info("Tanıtma isteği: %s (%s)", cihaz, ip)
                        self.olaylar.eslesme_istegi(cihaz, ip)
                    satir_yaz(sok, dict(temel, ok=False, neden="pin", yanlis=False,
                                        eslesme_acik=self.eslesme_acik()))
                    return sok.close()
            else:
                yeni_token = None

            with self.kilit:
                aktif = self.aktif
            baska_cihaz = aktif is not None and aktif.token != token

            if istek.get("tur") == "izle":
                return self._izleme(IzlemeOturumu(sok, adres, cihaz, token), temel)

            if istek.get("tur") == "kayit":
                satir_yaz(sok, dict(temel, ok=True))
                sok.sendall(kayit_son())
                return sok.close()

            if istek.get("tur") != "yayin":
                cevap = dict(temel, ok=True)
                if yeni_token:
                    cevap["token"] = yeni_token
                if baska_cihaz:
                    cevap["mesgul"] = aktif.cihaz_adi
                satir_yaz(sok, cevap)
                return sok.close()

            if baska_cihaz and istek.get("yeniden"):
                # Bağlantısı kopan telefon geri dönerken tahtayı yeniden ele geçirmeye çalışmasın.
                kayit.info("Yeniden bağlanma reddedildi (tahtada %s yansıtıyor): %s", aktif.cihaz_adi, cihaz)
                satir_yaz(sok, dict(temel, ok=False, neden="mesgul"))
                return sok.close()
            if baska_cihaz:
                sok.settimeout(DEVIR_SURESI + 15)
                izin = self.olaylar.devir_sor(cihaz, aktif.cihaz_adi)
                kayit.info("Devir isteği %s → %s: %s", aktif.cihaz_adi, cihaz, "izin" if izin else "red")
                if not izin:
                    satir_yaz(sok, dict(temel, ok=False, neden="reddedildi"))
                    return sok.close()
            cevap = dict(temel, ok=True)
            if yeni_token:
                cevap["token"] = yeni_token
            satir_yaz(sok, cevap)
            sok.settimeout(15)
            sok.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self._yayin(Oturum(sok, adres, cihaz, bool(istek.get("ses")), token,
                               kontrol=bool(istek.get("kontrol"))))
        except (OSError, ValueError, ConnectionError) as e:
            kayit.info("Bağlantı yarıda kaldı (%s): %s", ip, e)
            try:
                sok.close()
            except OSError:
                pass

    def _izleme(self, oturum, temel):
        with self.kilit:
            onceki = self.izleyen
            self.izleyen = oturum
        if onceki:
            onceki.kapat()
        try:
            olur, ek = self.olaylar.izleme_istegi(oturum)
        except Exception as e:  # arayüz hatası bağlantıyı askıda bırakmasın
            kayit.exception("İzleme başlatılamadı")
            olur, ek = False, f"hata: {e}"
        if not olur:
            kayit.info("Tahtayı izleme reddedildi (%s): %s", ek, oturum.cihaz_adi)
            satir_yaz(oturum.sok, dict(temel, ok=False, neden=ek))
            with self.kilit:
                if self.izleyen is oturum:
                    self.izleyen = None
            return oturum.kapat()
        kayit.info("Tahta tabletten kontrol ediliyor: %s (%s)", oturum.cihaz_adi, oturum.adres[0])
        with oturum.yazma:
            satir_yaz(oturum.sok, dict(temel, ok=True, **ek))
        oturum.hazir.set()
        oturum.sok.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        try:
            while True:
                tur, bayrak, zaman, uzunluk = BASLIK.unpack(tam_oku(oturum.sok, BASLIK.size))
                if uzunluk > 1024:
                    break
                veri = tam_oku(oturum.sok, uzunluk) if uzunluk else b""
                if tur == T_BITIR:
                    break
                if tur == T_GIRDI and len(veri) == DOKUNMA.size:
                    eylem, x, y = DOKUNMA.unpack(veri)
                    self.olaylar.girdi(oturum, eylem, x / 65535, y / 65535)
        except (OSError, ValueError, ConnectionError, struct.error):
            pass
        finally:
            oturum.kapat()
            with self.kilit:
                if self.izleyen is oturum:
                    self.izleyen = None
            kayit.info("Tahtanın kontrolü bitti: %s", oturum.cihaz_adi)
            self.olaylar.izleme_bitti(oturum)

    def _yayin(self, oturum):
        with self.kilit:
            onceki = self.aktif
            self.aktif = oturum
        if onceki:
            # Aynı cihaz yeniden bağlandıysa eski bağlantı zaten kopmuştur; devir değildir.
            if onceki.token == oturum.token:
                onceki.neden = "aynı cihaz yeniden bağlandı"
                onceki.kapat()
            else:
                onceki.kapat(K_DEVIR)
        kayit.info("Yansıtma başladı: %s (%s), ses=%s", oturum.cihaz_adi, oturum.adres[0], oturum.ses)
        self.olaylar.yayin_basladi(oturum)
        oturum.ping_baslat()
        neden = "bağlantı kapandı"
        try:
            while True:
                tur, bayrak, zaman, uzunluk = BASLIK.unpack(tam_oku(oturum.sok, BASLIK.size))
                if uzunluk > EN_BUYUK_KARE:
                    break
                veri = tam_oku(oturum.sok, uzunluk) if uzunluk else b""
                if tur == T_BITIR:
                    neden = "telefondan durduruldu"
                    break
                if tur != T_PING:
                    self.olaylar.kare(oturum, tur, bayrak, zaman, veri)
        except socket.timeout:
            neden = "telefondan veri gelmiyor (bağlantı koptu)"
        except (OSError, ValueError, ConnectionError, struct.error) as e:
            neden = f"bağlantı koptu ({e})"
        finally:
            kayit.info("Yansıtma bitti: %s — %s", oturum.cihaz_adi, oturum.neden or neden)
            oturum.kapat()
            with self.kilit:
                if self.aktif is oturum:
                    self.aktif = None
            self.olaylar.yayin_bitti(oturum)
